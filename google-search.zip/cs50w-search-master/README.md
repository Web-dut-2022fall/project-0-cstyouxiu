<!-- 本次作业分为四个部分，三个单独的搜索网页和一个总的跳转网页
三个单独的搜索网页分别是image-search.html、index.html和advanced-search.html
image-search.html是google搜索页面，本来应该进入google的图片搜索网页，但是由于防火墙的限制，无法打开该网页，所以我设置的是跳转到了百度的图片搜索网页，
advanced-search.html与其类似，跳转到了百度的高级搜索页面
而index.html是regular search网页，我设置的是跳转到了baidu.com
首先打开main.html，然后有三种选择,可以自由选择跳转到三种搜索网页的任意一个，
输入搜索内容跳转之后，由于防火墙限制，这里设置成跳转到了百度的搜索该内容的页面，然后就可以完成搜索 -->